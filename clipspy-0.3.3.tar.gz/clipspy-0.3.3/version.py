"""Versioning controlled via Git Tag, check setup.py"""

__version__ = "0.3.3"
